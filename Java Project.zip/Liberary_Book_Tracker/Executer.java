package Liberary_Book_Tracker;

import java.util.Scanner;

public class Executer {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Liberary lib = new Liberary();

        System.out.println("Login as (1. Admin / 2. Student): ");
        int role = sc.nextInt();
        boolean isAdmin = role == 1;

        while (true) {
            System.out.println("*** Library Menu ***");
            if (isAdmin) {
                System.out.println("1. Add Book");
                System.out.println("2. Show Books");
                System.out.println("3. Return Book");
                System.out.println("4. Borrow Book");
            } else {
                System.out.println("1. Show Books");
                System.out.println("2. Return Book");
                System.out.println("3. Borrow Book");
            }

            int ch = sc.nextInt();
            sc.nextLine();

            if (isAdmin) {
                switch (ch) {
                    case 1:
                        System.out.print("Enter Book Name: ");
                        String name = sc.nextLine();
                        System.out.print("Enter Author Name: ");
                        String author = sc.nextLine();
                        lib.addBook(name, author);
                        break;
                    case 2:
                        lib.displayBooks();
                        break;
                    case 3:
                        lib.showBorrowBook();
                        System.out.print("Which book to return (name)? ");
                        String returnName = sc.nextLine();
                        lib.returnBook(returnName);
                        break;
                    case 4:
                        lib.displayBooks();
                        System.out.print("Enter name to borrow: ");
                        String borrowName = sc.nextLine();
                        if (lib.borrowBook(borrowName)) {
                            System.out.println("Book issued.");
                        } else {
                            System.out.println("Cannot issue book.");
                        }
                        break;
                }
            } else {
                switch (ch) {
                    case 1:
                        lib.displayBooks();
                        break;
                    case 2:
                        lib.showBorrowBook();
                        System.out.print("Which book to return (name)? ");
                        String returnName = sc.nextLine();
                        lib.returnBook(returnName);
                        break;
                    case 3:
                        lib.displayBooks();
                        System.out.print("Enter name to borrow: ");
                        String borrowName = sc.nextLine();
                        if (lib.borrowBook(borrowName)) {
                            System.out.println("Book issued.");
                        } else {
                            System.out.println("Cannot issue book.");
                        }
                        break;
                }
            }

            System.out.println("Continue? (1/0)");
            if (sc.nextInt() != 1) break;
            sc.nextLine(); 
        }
        sc.close();
    }
}