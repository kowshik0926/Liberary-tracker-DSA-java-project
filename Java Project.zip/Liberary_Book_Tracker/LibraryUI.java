package Liberary_Book_Tracker;

import javax.swing.*;
import java.awt.*;

public class LibraryUI {
    private Liberary lib;

    public LibraryUI() {
        lib = new Liberary();

        JFrame frame = new JFrame("Library Tracker");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JButton showBooks = new JButton("Show Books");
        JButton addBook = new JButton("Add Book");
        JButton borrowBook = new JButton("Borrow Book");
        JButton returnBook = new JButton("Return Book");

        showBooks.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            for (String name : lib.getBooks().keySet()) {
                sb.append(name).append("\n");
            }
            JOptionPane.showMessageDialog(frame, sb.toString());
        });

        addBook.addActionListener(e -> {
            String name = JOptionPane.showInputDialog("Book Name:");
            String author = JOptionPane.showInputDialog("Author Name:");
            lib.addBook(name, author);
        });

        borrowBook.addActionListener(e -> {
            String name = JOptionPane.showInputDialog("Book to borrow:");
            if (lib.borrowBook(name)) {
                JOptionPane.showMessageDialog(frame, "Book issued.");
            } else {
                JOptionPane.showMessageDialog(frame, "Cannot issue book.");
            }
        });

        returnBook.addActionListener(e -> {
            String name = JOptionPane.showInputDialog("Book to return:");
            lib.returnBook(name);
        });

        JPanel panel = new JPanel();
        panel.add(showBooks);
        panel.add(addBook);
        panel.add(borrowBook);
        panel.add(returnBook);

        frame.getContentPane().add(BorderLayout.CENTER, panel);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new LibraryUI();
    }
}