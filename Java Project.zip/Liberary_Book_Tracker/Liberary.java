package Liberary_Book_Tracker;

import java.util.HashMap;
import java.util.Map;

public class Liberary {
    private HashMap<String, Book> books;

    public Liberary() {
        books = new HashMap<>();
    }

    public boolean addBook(String name, String author) {
        if (books.containsKey(name)) {
            System.out.println("Book already exists.");
            return false;
        }
        books.put(name, new Book(name, author));
        return true;
    }

    public void displayBooks() {
        if (books.isEmpty()) {
            System.out.println("Library is empty.");
            return;
        }
        int i = 1;
        for (String name : books.keySet()) {
            System.out.println((i++) + ". " + name);
        }
    }

    public void showBorrowBook() {
        for (Map.Entry<String, Book> entry : books.entrySet()) {
            if (entry.getValue().isBorrowed()) {
                System.out.println(entry.getKey());
            }
        }
    }

    public void returnBook(String name) {
        if (books.containsKey(name)) {
            books.get(name).setBorrowedStatus(false);
        } else {
            System.out.println("Book not found.");
        }
    }

    public boolean borrowBook(String name) {
        if (!books.containsKey(name)) return false;
        Book b = books.get(name);
        if (b.isBorrowed()) return false;
        b.setBorrowedStatus(true);
        return true;
    }

    public HashMap<String, Book> getBooks() {
        return books;
    }
}